<?php
$timeset = 'Asia/Jakarta'; // reference for timezone http://php.net/manual/en/timezones.php


$smtp = 'smtp.csv';
$mailist = [
	'file'				=> 'list.txt',
	'removeduplicate'	=> false,
];

$sender_setting = [
	'color'				=> true,
	'Host'				=> 'smtp-relay.gmail.com', // smtp.gmail.com or smtp-relay.gmail.com
	'Port'				=> '587',
	'Hostname'			=> "srv-".rand(1,9999).".gmail.com", // You can modify this one as your hostname
	'max'				=> '1', // total of emails to send per sending
	'delay'				=> '0', // delay for send
	'charset'			=> 'UTF-8',
	'encoding'			=> 'quoted-printable', // quoted-printable or base64 or 7bit or 8bit
	'priority'			=> '3',	// 1=high, 3=normal, 5=low
	'randomparam'		=> true,
	'link'				=> 'https://google.com', // input link here to use a random link fiture
	'header'			=> true,
];

$sender_inbox = [
	#--start--#
	[
		'fname' 				=> 'Service', // from name
		'fmail'					=> '##mix_normal_15##-##mix_normal_16##@##mix_normal_8##-##number_normal_8##.##randomdomain##',
		'subject' 				=> "Alert: Access Limited (reference ##number_normal_12##)",
		'attachfile'			=> '', // Your PDF File, leave it blank if you wont use it
		'attachname' 			=> "", // Custom your PDF File
		'letter'				=> 'Letter.html',

	],
	#--end--#


];

$sender_header = array(
	'Message-ID|<##mix_normal_20##@##mix_normal_19##.##mix_normal_18##>',
	'In-Reply-To|<##mix_normal_20##@##mix_normal_18##.##mix_normal_19##>',
);




?>